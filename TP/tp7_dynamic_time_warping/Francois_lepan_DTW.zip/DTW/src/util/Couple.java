package util;

public class Couple {

	public int x,y;

	public Couple() {
		x=0; 
		y=0;
	}

	public Couple(int x, int y) {
		this.x = x;
		this.y = y;
	}
}