import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import java.util.*;
import javax.swing.*;


public class FCM_Visa_ implements PlugIn {

	/** Returns the maximum of the array */
	public int IndiceMaxOfArray(double[] array,int val) 
	{
		double max = 0;
		int indice = 0;
		
		for (int i=0; i<val; i++) {
			if (array[i]>max) {
				max=array[i];
				indice=i;
			}
		}
		
		return indice;
	}
	
	/** return a random number between min and max */
	public int rand(int min, int max) { return min + (int)(new Random().nextDouble()*(max-min)); }

	
	/**  The main method called when plugin is used */
	public void run(String arg) {

		////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////
		////                ASKING FOR DATA TO THE USER                 ////
		////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////
		
		// Currently opened image
		ImagePlus currentImage = WindowManager.getCurrentImage();
		ImageProcessor currentImage_imgProc = currentImage.getProcessor();

		// Size of the images : witdth, height, nbPixels
		int currentImage_width = currentImage_imgProc.getWidth();
		int currentImage_height = currentImage_imgProc.getHeight();
		int currentImage_nbPixels = currentImage_width * currentImage_height;

		// The segmented image -> after the clustering
		ImagePlus imageSegmenteFCM = NewImage.createImage("Image segmentée par FCM",currentImage_width,currentImage_height,1,24,0);
		ImageProcessor imageSegmenteFCM_imgProc = imageSegmenteFCM.getProcessor();
		imageSegmenteFCM.show();

		// Ask for the number of classes (cluster) wanted
		String demande = JOptionPane.showInputDialog("Nombre de classes : ");
		int nbClasses = Integer.parseInt(demande);

		// Ask for the fuzzy index (2 is a good choice)
		demande = JOptionPane.showInputDialog("Valeur de m (indice de flou) : ");
		double indiceDeFlou_m = Double.parseDouble(demande);

		// Ask for the number of maximum iteration
		demande = JOptionPane.showInputDialog("Nombre d'iteration max : ");
		int nbIterationMaximum =Integer.parseInt(demande);

		// Ask for the stability threshold
		demande = JOptionPane.showInputDialog("Valeur du seuil de stabilite : ");
		double seuilDeStabilite = Double.parseDouble(demande);

		// Ask if the user want a better randomization 
		demande = JOptionPane.showInputDialog("Randomisation amelioree ? (0 = non ou 1 = oui)");
		int bool = Integer.parseInt(demande);
		
		
		// the boolean that tells if the user ask for a better randomization  
		boolean randomisationAmelioree = bool==1;
		// the centroids
		double centroids[][] = new double[nbClasses][3];
		// the distances between the data and the centroids
		double distancesDataCentroids[][] = new double[nbClasses][currentImage_nbPixels];
		// the repartition matrix
		double Umat[][] = new double[nbClasses][currentImage_nbPixels];
		// the color component
		double red[] = new double[currentImage_nbPixels];
		double green[] = new double[currentImage_nbPixels];
		double blue[] = new double[currentImage_nbPixels];
		
		
		double figJ[]=new double[nbIterationMaximum];
		for(int i=0; i<nbIterationMaximum; i++) { 
			figJ[i]=0;
		}

		// Récupération des données images 
		int l = 0;
		for(int i = 0; i < currentImage_width; i++)
		{
			for(int j = 0; j < currentImage_height; j++)
			{
				int[] colorarray = new int[3];
				currentImage_imgProc.getPixel(i,j,colorarray);
				red[l] = (double)colorarray[0];
				green[l] = (double) colorarray[1];
				blue[l] = (double)colorarray[2];
				l++;
			}
		}
		
		////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////
		////                          FCM                               ////
		////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////
				
		////////////////////////////////////////////
		////////    INITIALIZATION FCM    //////////
		////////////////////////////////////////////

		// Initialization of the centroids (randomly)
		int epsilonx,epsilony;
		int[] init=new int[3];
		
		for(int i=0; i<nbClasses; i++)
		{
			if(randomisationAmelioree) 
			{  
				epsilonx=rand((int)(currentImage_width/(i+2)),(int)(currentImage_width/2));
				epsilony=rand((int)(currentImage_height/(4)),(int)(currentImage_height/2));
			}
			else
			{
				epsilonx=0;
				epsilony=0;
			}
			
			int rx = rand(0+epsilonx, currentImage_width-epsilonx);
			int ry = rand(0+epsilony, currentImage_height-epsilony);
			
			currentImage_imgProc.getPixel(rx,ry,init);
			
			centroids[i][0] = init[0]; 
			centroids[i][1] =init[1];
			centroids[i][2] = init[2];
		}

		// computing the distances between the data and the centrids
		for(l = 0; l < currentImage_nbPixels; l++)
		{
			for(int k = 0; k < nbClasses; k++)
			{
				double r2 = Math.pow(red[l] - centroids[k][0], 2);
				double g2 = Math.pow(green[l] - centroids[k][1], 2);
				double b2 = Math.pow(blue[l] - centroids[k][2], 2);
				distancesDataCentroids[k][l] = r2 + g2 + b2;
			}
		}

		//////////////////////////////////////////////////
		////            The working area               /// 
		//////////////////////////////////////////////////

		// Initialization of the membership degree
        for (int i = 0; i < nbClasses; i++) {
			for (int j = 0; j < currentImage_nbPixels; j++) {
				double appartenance = 0;
				for (int k = 0; k < nbClasses; k++) {
					if (distancesDataCentroids[k][j] != 0) {
						appartenance += Math.pow(distancesDataCentroids[i][j]/distancesDataCentroids[k][j] , 2/(indiceDeFlou_m-1));
					} else {
						appartenance += 1;
					}
				}
				
				Umat[i][j] = 1 / appartenance;
			}
		}
		//////////////////////////////////////////////////
		////            The working area               /// 
		//////////////////////////////////////////////////

        
        ////////////////////////////////////////////
		////////  END INITIALIZATION FCM  //////////
		////////////////////////////////////////////

		/////////////////////////////////////////////////////////////
		//////                 MAIN LOOP                    /////////
		/////////////////////////////////////////////////////////////
		int iter = 0;
		int stab = 2;

		while ((iter < nbIterationMaximum) && (stab > seuilDeStabilite)) 
		{
			//////////////////////////////////////////////////
			////            The working area               /// 
			//////////////////////////////////////////////////

			// Update the matrix of centroids
			for(int i=0; i<nbClasses; i++) {
				
				double composanteRouge = 0;
				double composanteVert = 0;
				double composanteBleu = 0;
				double somme = 0;
				
				for (int j = 0; j < currentImage_nbPixels; j++) {
					somme += Math.pow(Umat[i][j],indiceDeFlou_m);
					composanteRouge += Math.pow(Umat[i][j],indiceDeFlou_m)*red[j];
					composanteVert += Math.pow(Umat[i][j],indiceDeFlou_m)*green[j];
					composanteBleu += Math.pow(Umat[i][j],indiceDeFlou_m)*blue[j];
				}
				
				if (somme > 0 ) {
					centroids[i][0] = composanteRouge / somme;
					centroids[i][1] = composanteVert / somme;
					centroids[i][2] = composanteBleu / somme;
				}
			}
			
			// Compute distancesDataCentroids, the matrix of distances (euclidian) with the centroids
			for(l = 0; l < currentImage_nbPixels; l++)
			{
				for(int k = 0; k < nbClasses; k++)
				{
					double r2 = Math.pow(red[l] - centroids[k][0], 2);
					double g2 = Math.pow(green[l] - centroids[k][1], 2);
					double b2 = Math.pow(blue[l] - centroids[k][2], 2);
					distancesDataCentroids[k][l] = r2 + g2 + b2;
				}
			}
			
			// re compute the membership degree
			for (int i = 0; i < nbClasses; i++) {
				for (int j = 0; j < currentImage_nbPixels; j++) {
					
					double appartenance = 0;
					for (int k = 0; k < nbClasses; k++) {
						
						if (distancesDataCentroids[k][j] > 0) {
							
							appartenance += Math.pow(distancesDataCentroids[i][j]/distancesDataCentroids[k][j] , 2/(indiceDeFlou_m-1));
						} else {
							appartenance += 1;
						}
					}

					Umat[i][j] = 1 / appartenance;
				}
			}
			
			// Calculate difference between the previous partition and the new partition (performance index)
			double performance = 0;
			for (int i = 0; i < nbClasses; i++) {
				
				for (int j = 0; j < currentImage_nbPixels; j++) {
					
					performance += Math.pow(Umat[i][j],indiceDeFlou_m) * distancesDataCentroids[i][j] ;
					
				}
			}

			figJ[iter] = performance;

			iter++;
			
			//////////////////////////////////////////////////
			////            The working area               /// 
			//////////////////////////////////////////////////

			// Affichage de l'image segmentee 
			double[] mat_array=new double[nbClasses];
			l = 0;
			for(int i=0; i<currentImage_width; i++)
			{
				for(int j = 0; j<currentImage_height; j++)
				{
					for(int k = 0; k<nbClasses; k++)
					{ 
						mat_array[k]=Umat[k][l];
					}
					
					int indice = IndiceMaxOfArray(mat_array,nbClasses);
					
					int array[] = new int[3];
					array[0] = (int)centroids[indice][0];
					array[1] = (int)centroids[indice][1];
					array[2] = (int)centroids[indice][2];
					imageSegmenteFCM_imgProc.putPixel(i, j, array);
					l++;
				}
			}
			imageSegmenteFCM.updateAndDraw();
		}

		double[] xplot= new double[nbIterationMaximum];
		double[] yplot=new double[nbIterationMaximum];
		for(int w = 0; w < nbIterationMaximum; w++)
		{
			xplot[w]=(double)w;	
			yplot[w]=(double) figJ[w];
		}
		Plot plot = new Plot("Performance Index (FCM)","iterations","J(P) value",xplot,yplot);
		plot.setLineWidth(2);
		plot.setColor(Color.blue);
		plot.show();
	} // Fin FCM
}